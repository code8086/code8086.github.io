<?php
    require("include/config.php");
    $conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting.");
    mysql_query("set names 'utf8'");
    mysql_select_db("$mysql_database");
    $delete_id = $_GET['id'];
    echo $delete_id;
    $sql = "delete from info where ID=".$delete_id;
    $result = mysql_query($sql,$conn);
?>

<script type="text/javascript">
    window.location.replace("index.php")
</script>
