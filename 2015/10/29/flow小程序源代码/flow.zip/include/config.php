<?php
$mysql_server_name='localhost';
$mysql_username='root';
$mysql_password='solo2015.';
$mysql_database='flow';
?>
