<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>小熊de时间轴</title>
<link rel="stylesheet" href="css/main.css" />
<link rel="stylesheet" href="css/style.css" />
<style type="text/css">
h2.top_title{border-bottom:none;background:none;text-align:center;line-height:32px; font-size:20px}
h2.top_title span{font-size:12px; color:#666;font-weight:500}
</style>
</head>

<body>


<h2 class="top_title"><a href="http://www.helloweba.com/view-blog-285.html">小熊熊的时间轴</a><br/><span>我的故事，我自己来写。</span></h2>

<section id="cd-timeline" class="cd-container">
	<div class="cd-timeline-block">

    <?php
        require("include/config.php");
        $conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting.");
        mysql_query("set names 'utf8'");
        mysql_select_db("$mysql_database");
        $sql = "select * from info";
        $result = mysql_query($sql, $conn);
        while($row = mysql_fetch_array($result))
        {
            echo "<div class='cd-timeline-content'>";
            echo "<p>".$row['flowmsg']."</p>";
						echo "<a href=\"http://flow.code8086.com/delete.php?id=". $row['ID'] ."\" class=\"cd-read-more\">删除</a>";
						echo "<span class='cd-date'>" . $row['flowtime'] . "</span>";
            echo "</div>";

            echo "<br/>";
        }
    ?>
<!---
		<div class="cd-timeline-content">
			<h2>收集整理的非常有用的PHP函数</h2>
			<p>项目中经常会需要一些让人头疼的函数，作为开发者应该整理一个自己的函数库，在需要之时复制过来即可。本文作者收集整理数十个PHP项目中常用的函数，保证能正常运行，你只要复制粘贴到你项目中即可。</p>
			<a href="http://www.helloweba.com/view-blog-281.html" class="cd-read-more" target="_blank">阅读全文</a>
			<span class="cd-date">2014-12-05</span>
		</div>
    --->
	</div>
  <div>
    <a href="write.php">添加</a>
  </div>
</section>

<div id="footer">
    <p>Powered by code8086</a></p>
</div>
</body>
</html>
