<?php
    require("include/config.php");
    $conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting.");
    mysql_query("set names 'utf8'");
    mysql_select_db("$mysql_database");

    date_default_timezone_set('PRC');
    $post_time=date('y-m-d H:i:s',time());

    $sql = "insert into info(flowtime,flowmsg) values('". $post_time ."','".$_POST["msg"]."')";
    $result = mysql_query($sql,$conn);
?>

<script type="text/javascript">
    window.location.replace("index.php")
</script>
