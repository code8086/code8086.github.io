<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>小熊的时间轴</title>
<link rel="stylesheet" href="css/main.css" />
<link rel="stylesheet" href="css/style.css" />
<style type="text/css">
h2.top_title{border-bottom:none;background:none;text-align:center;line-height:32px; font-size:20px}
h2.top_title span{font-size:12px; color:#666;font-weight:500}
</style>
</head>
<body>
    <div class="cd-timeline-block">
        <form action="post.php" method="post">
            <input type="text" name="msg"/>
            <input class="cd-read-more" type="submit"/>
        </form>
    </div>
</body>
</html>
